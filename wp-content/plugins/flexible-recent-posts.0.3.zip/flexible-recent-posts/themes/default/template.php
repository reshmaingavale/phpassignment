<h4 class="news-widget-title">[frp_title]</h4>
<div class="news-widget-excerpt">[frp_thumbnail size="32x32"][frp_excerpt] <a
	href="[frp_link]"><?php _e( 'read more', 'frp' ); ?></a></div>
<div class="news-widget-date">[frp_date format="d.m.Y"]</div>