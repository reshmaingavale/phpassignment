<h4 class="news-widget-title">[frp_title]</h4>
<div class="news-widget-excerpt">[frp_thumbnail size="32x32"][frp_excerpt] <a href="[frp_link]">read more</a></div>
<div class="news-widget-date">[frp_date time_since="1" format="d.m.Y"]</div>[frp_author]